import React from "react";
import "./App.css";
import BoxGenerator from "./components/boxgenerator";

function App() {
  return (
    <div className="App">
      <BoxGenerator />
    </div>
  );
}

export default App;
